# text_editor_python
This is text editor app created in python.
